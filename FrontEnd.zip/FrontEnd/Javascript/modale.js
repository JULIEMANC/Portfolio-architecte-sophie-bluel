
// car si on n'appuie pas dessus elle ne s'affaiche 
let modal = null
// recuperation div projectandMod
const projectandMod = document.querySelector(".projectandMod")

// recuperer la modal
const modal1 = document.getElementById("modal1")

// recuperation de la div qui accueille les photos 
const gallery = document.querySelector(".galleryPhoto")

// // Récupérer le formulaire et le bouton submit
// const form = document.getElementById("modalAddwork");

/*
function setupModal (les fonciton open/close des modal, mettre en place l'interaction uniquement)
fonction display (affichage des travaux dans la modal)
fonction setDeleteListener (mise en place du listener sur les icone de poubelle)
function deleteWork (appel de l'api)

*/
/*On ouvre la modal */
export {setupModal} 
function setupModal (){
const openModal = function (e) {
 e.preventDefault()


  const target = document.querySelector(e.target.getAttribute('href'))
  target.style.display = null 
  
  target.removeAttribute('aria-hidden')
  target.setAttribute('arria-modal', 'true')
  
  modal = target

  modal.addEventListener('click', closeModal)
  modal.querySelector('.js-modal-close').addEventListener('click', closeModal)
  modal.querySelector('.js-modal-stop').addEventListener('click', stopPropagation)
/*Pour fermer boite modal avec button */
const closeModal = function (e) {
  if (modal == null) return
  e.preventDefault()
  modal.style.display = "none"
}

/* Pour pas que la boite se ferme si on appuie dessus hors le button */
const stopPropagation = function (e) {
  e.stopPropagation()
}
document.querySelectorAll(".js-modal").forEach(a => {
  a.addEventListener("click", openModal)
} )
}
}



// // // Fonction pour supprimer 
// function DeleteWork(event) {
//   DeleteWork(this.dataset.id);

// } 

// // Récupération des projets via l'API
// // 1111function display(){}

// fetch("http://localhost:5678/api/works")
//   .then(response => response.json())
//   .then(data => {
//     for (let i = 0; i < data.length; i++) { /*(const work of allWorks) {let allWorks = add(work) */
//       let figure = document.createElement("figure")
//       let img = document.createElement("img")
//       let deleteIcon = document.createElement("i")
//       deleteIcon.className = "deleteIcon"
//       let figcaption = document.createElement("figcaption")


//       img.src = data[i].imageUrl;
//       img.alt = data[i].title;

//       figcaption.textContent = "éditer";
//       deleteIcon.classList.add("fa-solid", "fa-trash-can", "delete-icon")
//       deleteIcon.setAttribute("data-id", data[i].id)
    

//       figcaption.appendChild(deleteIcon)
//       figure.appendChild(img)
//       figure.appendChild(figcaption)
//       figure.classList.add("figure-modal-add")

//       gallery.appendChild(figure)
//     }

//   })
//   .catch(error => console.error(error))


// 1111function updateAfterDelete (){}
// // function updateAfterDelete(){}
//     const deleteIcons = [...document.querySelectorAll(".deleteIcon")] 
//  //supprime une image de la galerie et de la base de données icone poubelle
//   for (const poubelle of deleteIcons) {
//     poubelle.addEventListener("click", (event) => {
//       event.preventDefault() 

   
// //pr que la poubelle puisse delete en fonction d'un click (appel a l'api)
//1111function deleteWork(){}
// const workId = poubelle.dataset.id
    
//       let token = sessionStorage.getItem("token")
//       fetch(`http://localhost:5678/api/works/${workId}`, {
//         method: "DELETE",
//         headers: {
//           "Authorization": `bearer ${token}`
//         }
//       })
//         .then(function (response) {
//           if (response.ok) {
//             updateAfterDelete(workId)
//             displayWorks() // affiche projet mis a jour dans page accueil 
//           } else {
//             console.log("Erreur lors de la suppression de l/'élément ")
//           }
//         })
//         .catch(function (error) {
//           console.log("Erreur lors de la suppresion de l/'élement", error)
//         })

//     })
//   }
// }





// // récuperation du bouton ajouter photo de la modal 1
// const buttonAddPhotos = document.querySelector(".buttonAddPhotos")

// // //ajout d'un evenement click au btn ajouter photo modal 1
// buttonAddPhotos.addEventListener("click", () => {
//   modalAddwork.style.display = "block"
//   modal1.style.display = "none"
// })



// MODAL 2//  

// // Fonction pour réinitialiser le formulaire
// function resetForm() {
//   let imgPreview = document.querySelector(".img");
//   if (imgPreview !== null) {
//     imgPreview.remove();
//   }
//   document.getElementById("input-container").style.display = "";
//   document.querySelector("#img-container p").style.display = "";
//   form.reset();
// // }

// // Récupérer la modal-addwork
// const modalAddwork = document.querySelector(".modal-addwork");

// // recuperer fleche retour 
// const backArrow = document.querySelector(".fa-solid.fa-arrow-left")

// //ajout element click a la fleche retour
// backArrow.addEventListener("click", function () {
//   modalAddwork.style.display = "none" //masquer modalAddwork
//   modal1.style.display = "block" //affiche modal1
// })

// //recuperation croix close modalAddwork
// const closeIcon = document.querySelector("#close2")

// //ajout dun listener sur le bouton pr fermer la modal
// closeIcon.addEventListener("click", function () {
//   modalAddwork.style.display = "none"
//   //Reinitialiser le champs du formulaire
//   document.getElementById("form-addWork").reset()
// })




// //on recupere la liste déroulante de catégorie option 
// const categorySelect=document.getElementById("category-option")

// //récupere les categories depuis l'api
// fetch ("http://localhost:5678/api/categories")
// .then (response => response.json())
// .then (data =>{ 
//   //parcourir les catégories et créer option pr chacune delles 
//   for(let i=0; i<data.length; i++){
//     let option = document.createElement("option")
//     option.value= data[i].id;
//     option.text=data[i].name;
//     categorySelect.appendChild(option)
//   }
// })
// .catch(error=> console.error(error))

// // Récupére les éléments du formulaire
// const titleInput = document.getElementById("title-img");
// const imageInput = document.getElementById("add-imgbutton");

// //ecoute du click sur le bouton ajout photo
// imgButton.addEventListener("change", ()=>{
//   const file=this.files[0];
//   const reader=new FileReader();
// })
  
// // Vérifier le format et la taille du fichier
//   const allowedFormats = ["image/jpeg", "image/png"];
//   const maxSize = 4 * 1024 * 1024; 